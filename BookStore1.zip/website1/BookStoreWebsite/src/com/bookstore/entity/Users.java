package com.bookstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;



@Entity
@NamedQueries({
	@NamedQuery(name = "Users.findAll" , query = "SELECT u FROM Users u ORDER BY u.full_name"),
	@NamedQuery(name = "Users.findByEmail" , query = "SELECT u FROM Users u WHERE u.email = :email"),
	@NamedQuery(name = "Users.countAll" , query = "SELECT count(*)FROM Users u"),
		@NamedQuery(name = "Users.checkLogin" , query = "SELECT u FROM Users u WHERE u.email = :email AND password = :password")
	
})
public class Users {
	private Integer userId;
	private String email;
	private String full_name;
	private String password;

		
	
	
	public Users() {
	}

	public Users(Integer userId ,String email, String full_name, String password) {
		this(email, full_name, password);
		this.userId= userId;
	}
	
	
	public Users(String email, String full_name, String password) {
		super();
		this.email = email;
		this.full_name = full_name;
		this.password = password;
	}

	@Id
	@Column(name = "user_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFull_name() {
		return full_name;
	}

	
	public void setFull_name(String full_name) {
		this.full_name = full_name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
