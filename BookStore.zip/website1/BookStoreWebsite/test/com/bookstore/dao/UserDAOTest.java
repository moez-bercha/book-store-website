package com.bookstore.dao;

import static org.junit.Assert.*;

import java.util.List;

import javax.persistence.PersistenceException;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.bookstore.entity.Users;

public class UserDAOTest extends BaseDAOTest {
	private static UserDAO userDAO;

	@BeforeClass
	public static void setupClass() throws Exception {
		BaseDAOTest.setUpBeforeClass();
		userDAO = new UserDAO(entityManager);
	}

	@Test
	public void testCreateUsers() {
		Users user1 = new Users();
		user1.setEmail("rizwan@gmail.com");
		user1.setFull_name("rizwan Bercha");
		user1.setPassword("karimbercha");
		user1 = userDAO.create(user1);
		assertTrue(user1.getUserId() > 0);
	}

	@Test(expected = PersistenceException.class)
	public void testCreateUsersFeildsNotSet() {
		Users user1 = new Users();
		user1 = userDAO.create(user1);
		assertTrue(user1.getUserId() > 0);
	}

	@Test
	public void testUpdateUser() {
		Users user = new Users();
		user.setUserId(20);
		user.setFull_name("Fahim Bercha");
		user.setEmail("fahim@gmail.com");
		user.setPassword("123456789");

		user = userDAO.update(user);
		String expected = "fahim@gmail.com";
		String actual = user.getEmail();

		assertEquals(expected, actual);

	}

	@Test
	public void testGetUsersFound() {
		Integer userid = 20;
		Users user = userDAO.get(userid);
		if (user != null) {
			System.out.println(user.getEmail());
		}
		assertNotNull(user);
	}

	@Test
	public void testGetUsersNotFound() {
		Integer userid = 123;
		Users user = userDAO.get(userid);

		assertNull(user);
	}

	@Test
	public void testDeleteUser() {
		Integer userid = 24;
		userDAO.delete(userid);
		Users user = userDAO.get(userid);
		assertNull(user);
	}

	@Test(expected = Exception.class)
	public void testDeleteUserNotExists() {
		Integer userid = 23;
		userDAO.delete(userid);
		Users user = userDAO.get(userid);

		assertNull(user);
	}

	@Test
	public void testListAll() {
		List<Users> listUsers = userDAO.listAll();
		for (Users user : listUsers) {
			System.out.println(user.getEmail());
			System.out.println(user.getFull_name());
		}
		assertTrue(listUsers.size() > 0);
	}

	@Test
	public void testCount() {
		long totalUsers = userDAO.count();
		assertEquals(17, totalUsers);
	}

	@Test
	public void testFindByEmail() {
		String email = "moez@gmail.com";
		Users user = userDAO.findByEmail(email);

		assertNotNull(user);
	}

	@Test
	public void testCheckLoginSuccess() {
		String email = "moez@gmail.com";
		String password = "sda";

		boolean loginResult = userDAO.checkLogin(email, password);

		assertTrue(loginResult);

	}

	@Test
	public void testCheckLoginFail() {
		String email = "moezbercha@gmail.com";
		String password = "sda";

		boolean loginResult = userDAO.checkLogin(email, password);

		assertFalse(loginResult);

	}

	@AfterClass
	public static void tearDownClass() throws Exception {
		BaseDAOTest.tearDownAfterClass();
	}
}
